#ifndef __DEF_H__
#define __DEF_H__

struct shape {
	int s[5][5];
};

extern struct shape shape_arr[7];

#endif // __DEF_H__

